./graph_viewer ./paper/our2/dlpb_100/outputs_convert/polyline_point.txt ./paper/our2/dlpb_100/outputs_convert/edgelist.txt ./paper/our2/dlpb_100 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 1300 ./paper/our2/dlpb_100/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_100/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_100/outputs_convert/edgelist.txt ./paper/our3/dlpb_100 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 1300 ./paper/our3/dlpb_100/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our2/dlpb_300/outputs_convert/polyline_point.txt ./paper/our2/dlpb_300/outputs_convert/edgelist.txt ./paper/our2/dlpb_300 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3335 ./paper/our2/dlpb_300/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_300/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_300/outputs_convert/edgelist.txt ./paper/our3/dlpb_300 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3335 ./paper/our3/dlpb_300/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our2/dlpb_500/outputs_convert/polyline_point.txt ./paper/our2/dlpb_500/outputs_convert/edgelist.txt ./paper/our2/dlpb_500 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4787 ./paper/our2/dlpb_500/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_500/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_500/outputs_convert/edgelist.txt ./paper/our3/dlpb_500 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4787 ./paper/our3/dlpb_500/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our2/dlpb_700/outputs_convert/polyline_point.txt ./paper/our2/dlpb_700/outputs_convert/edgelist.txt ./paper/our2/dlpb_700 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 5974 ./paper/our2/dlpb_700/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_700/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_700/outputs_convert/edgelist.txt ./paper/our3/dlpb_700 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 5974 ./paper/our3/dlpb_700/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our2/dlpb_900/outputs_convert/polyline_point.txt ./paper/our2/dlpb_900/outputs_convert/edgelist.txt ./paper/our2/dlpb_900 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 7171 ./paper/our2/dlpb_900/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_900/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_900/outputs_convert/edgelist.txt ./paper/our3/dlpb_900 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 7171 ./paper/our3/dlpb_900/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
