./graph_viewer ./paper/our2/dlpb_small/outputs_convert/polyline_point.txt ./paper/our2/dlpb_small/outputs_convert/edgelist.txt ./paper/our2/dlpb_small 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4787 ./paper/our2/dlpb_small/outputs_convert/node_polygon_mapping.txt .6 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our3/dlpb_small/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_small/outputs_convert/edgelist.txt ./paper/our3/dlpb_small 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4787 ./paper/our3/dlpb_small/outputs_convert/node_polygon_mapping.txt .6 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our2/fullkmp/outputs_convert/polyline_point.txt ./paper/our2/fullkmp/outputs_convert/edgelist.txt ./paper/our2/fullkmp 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 5180 ./paper/our2/fullkmp/outputs_convert/node_polygon_mapping.txt .6 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our3/fullkmp/outputs_convert/Vpolygon_points.txt ./paper/our3/fullkmp/outputs_convert/edgelist.txt ./paper/our3/fullkmp 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 5180 ./paper/our3/fullkmp/outputs_convert/node_polygon_mapping.txt .6 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
