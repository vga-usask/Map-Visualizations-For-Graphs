./graph_viewer ./paper/our3/small_graph_size_5_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_5_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_5_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 1095 ./paper/our3/small_graph_size_5_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_5_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_5_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_5_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 1095 ./paper/our2/small_graph_size_5_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our3/small_graph_size_10_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_10_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_10_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 1866 ./paper/our3/small_graph_size_10_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_10_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_10_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_10_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 1866 ./paper/our2/small_graph_size_10_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our3/small_graph_size_15_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_15_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_15_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 2436 ./paper/our3/small_graph_size_15_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_15_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_15_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_15_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 2436 ./paper/our2/small_graph_size_15_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our3/small_graph_size_20_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_20_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_20_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 2893 ./paper/our3/small_graph_size_20_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_20_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_20_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_20_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 2893 ./paper/our2/small_graph_size_20_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our3/small_graph_size_25_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_25_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_25_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3269 ./paper/our3/small_graph_size_25_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_25_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_25_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_25_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3269 ./paper/our2/small_graph_size_25_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our3/small_graph_size_30_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_30_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_30_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3573 ./paper/our3/small_graph_size_30_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_30_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_30_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_30_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3573 ./paper/our2/small_graph_size_30_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our3/small_graph_size_35_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_35_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_35_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3808 ./paper/our3/small_graph_size_35_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_35_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_35_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_35_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3808 ./paper/our2/small_graph_size_35_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our3/small_graph_size_40_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_40_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_40_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4001 ./paper/our3/small_graph_size_40_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_40_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_40_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_40_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4001 ./paper/our2/small_graph_size_40_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our3/small_graph_size_45_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_45_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_45_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4160 ./paper/our3/small_graph_size_45_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_45_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_45_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_45_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4160 ./paper/our2/small_graph_size_45_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our3/small_graph_size_50_graph_1/outputs_convert/Vpolygon_points.txt ./paper/our3/small_graph_size_50_graph_1/outputs_convert/edgelist.txt ./paper/our3/small_graph_size_50_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4286 ./paper/our3/small_graph_size_50_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/small_graph_size_50_graph_1/outputs_convert/polyline_point.txt ./paper/our2/small_graph_size_50_graph_1/outputs_convert/edgelist.txt ./paper/our2/small_graph_size_50_graph_1 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4286 ./paper/our2/small_graph_size_50_graph_1/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

