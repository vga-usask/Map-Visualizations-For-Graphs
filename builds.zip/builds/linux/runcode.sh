
./graph_viewer ./paper/our2/bookland/outputs_convert/polyline_point.txt ./paper/our2/bookland/outputs_convert/edgelist.txt ./paper/our2/bookland 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 499 ./paper/our2/bookland/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our2/musicland/outputs_convert/polyline_point.txt ./paper/our2/musicland/outputs_convert/edgelist.txt ./paper/our2/musicland 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 250 ./paper/our2/musicland/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our2/recipies/outputs_convert/polyline_point.txt ./paper/our2/recipies/outputs_convert/edgelist.txt ./paper/our2/recipies 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 369 ./paper/our2/recipies/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our2/tradeland/outputs_convert/polyline_point.txt ./paper/our2/tradeland/outputs_convert/edgelist.txt ./paper/our2/tradeland 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 150 ./paper/our2/tradeland/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our2/universities/outputs_convert/polyline_point.txt ./paper/our2/universities/outputs_convert/edgelist.txt ./paper/our2/universities 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 161 ./paper/our2/universities/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/bookland/outputs_convert/Vpolygon_points.txt ./paper/our3/bookland/outputs_convert/edgelist.txt ./paper/our3/bookland 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 499 ./paper/our3/bookland/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/musicland/outputs_convert/Vpolygon_points.txt ./paper/our3/musicland/outputs_convert/edgelist.txt ./paper/our3/musicland 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 250 ./paper/our3/musicland/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/recipies/outputs_convert/Vpolygon_points.txt ./paper/our3/recipies/outputs_convert/edgelist.txt ./paper/our3/recipies 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 369 ./paper/our3/recipies/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/tradeland/outputs_convert/Vpolygon_points.txt ./paper/our3/tradeland/outputs_convert/edgelist.txt ./paper/our3/tradeland 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 150 ./paper/our3/tradeland/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/universities/outputs_convert/Vpolygon_points.txt ./paper/our3/universities/outputs_convert/edgelist.txt ./paper/our3/universities 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 161 ./paper/our3/universities/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our2/dlpb_100/outputs_convert/polyline_point.txt ./paper/our2/dlpb_100/outputs_convert/edgelist.txt ./paper/our2/dlpb_100 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 1300 ./paper/our2/dlpb_100/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_100/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_100/outputs_convert/edgelist.txt ./paper/our3/dlpb_100 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 1300 ./paper/our3/dlpb_100/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our2/dlpb_300/outputs_convert/polyline_point.txt ./paper/our2/dlpb_300/outputs_convert/edgelist.txt ./paper/our2/dlpb_300 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3335 ./paper/our2/dlpb_300/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_300/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_300/outputs_convert/edgelist.txt ./paper/our3/dlpb_300 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 3335 ./paper/our3/dlpb_300/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our2/dlpb_500/outputs_convert/polyline_point.txt ./paper/our2/dlpb_500/outputs_convert/edgelist.txt ./paper/our2/dlpb_500 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4787 ./paper/our2/dlpb_500/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_500/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_500/outputs_convert/edgelist.txt ./paper/our3/dlpb_500 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 4787 ./paper/our3/dlpb_500/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our2/dlpb_700/outputs_convert/polyline_point.txt ./paper/our2/dlpb_700/outputs_convert/edgelist.txt ./paper/our2/dlpb_700 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 5974 ./paper/our2/dlpb_700/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_700/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_700/outputs_convert/edgelist.txt ./paper/our3/dlpb_700 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 5974 ./paper/our3/dlpb_700/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10

./graph_viewer ./paper/our2/dlpb_900/outputs_convert/polyline_point.txt ./paper/our2/dlpb_900/outputs_convert/edgelist.txt ./paper/our2/dlpb_900 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 7171 ./paper/our2/dlpb_900/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_900/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_900/outputs_convert/edgelist.txt ./paper/our3/dlpb_900 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 7171 ./paper/our3/dlpb_900/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 10
./graph_viewer ./paper/our3/dlpb_small/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_small/outputs_convert/edgelist.txt ./paper/our3/dlpb_small 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 26325 ./paper/our3/dlpb_small/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/dlpb_small/outputs_convert/polyline_point.txt ./paper/our2/dlpb_small/outputs_convert/edgelist.txt ./paper/our2/dlpb_small 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 26325 ./paper/our2/dlpb_small/outputs_convert/node_polygon_mapping.txt .7 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

sleep 10

./graph_viewer ./paper/our3/dlpb_full/outputs_convert/Vpolygon_points.txt ./paper/our3/dlpb_full/outputs_convert/edgelist.txt ./paper/our3/dlpb_full 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 40312 ./paper/our3/dlpb_full/outputs_convert/node_polygon_mapping.txt .5 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30
./graph_viewer ./paper/our2/dlpb_full/outputs_convert/polyline_point.txt ./paper/our2/dlpb_full/outputs_convert/edgelist.txt ./paper/our2/dlpb_full 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 40312 ./paper/our2/dlpb_full/outputs_convert/node_polygon_mapping.txt .5 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt

sleep 30

./graph_viewer ./paper/our2/fullkmp/outputs_convert/polyline_point.txt ./paper/our2/fullkmp/outputs_convert/edgelist.txt ./paper/our2/fullkmp 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 14906 ./paper/our2/fullkmp/outputs_convert/node_polygon_mapping.txt .5 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
sleep 30

./graph_viewer ./paper/our3/fullkmp/outputs_convert/Vpolygon_points.txt ./paper/our3/fullkmp/outputs_convert/edgelist.txt ./paper/our3/fullkmp 2000 1 wg 1 1 approximate 1 1 1 png svg gpu 14906 ./paper/our3/fullkmp/outputs_convert/node_polygon_mapping.txt .5 1 1 ./polygon/default_node_map_dep_map.txt ./polygon/default_node_map_dep_map.txt
